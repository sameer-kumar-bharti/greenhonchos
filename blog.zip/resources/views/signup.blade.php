@extends('layout.app')
@section('content')
@include('layout.navbar')
<div class="modal-body">
    <form action="{{url('user_signup')}}" method="post">
        @csrf
        <div class="form-group">
            <label for="exampleInputEmail1">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{old('name')}}" aria-describedby="emailHelp" placeholder="Enter name">
            @error('name')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" class="form-control" id="email" name="email" value="{{old('email')}}" aria-describedby="emailHelp" placeholder="Enter email">
            @error('email')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" name="password" id="password" value="{{old('password')}}" placeholder="Password">
            @error('password')
                <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;<span><a id="" class="signin" href="{{url('login')}}">Sign in</a></span>
    </form>
</div>
@endsection