<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use App\Models\User;
use Str;
use Session;
use DB;
class BlogController extends Controller
{
    public function index(Request $request){
        $search = $request->search;
        if($search!= null){
            $all_blogs = Blog::where('title', 'LIKE', '%' . $search . '%')
                    ->orWhere('content', 'LIKE', '%' . $search . '%')
                    ->get();
        }else{
            $all_blogs = Blog::get();
        }
        return view('index',compact('all_blogs'));
    }

    public function dashboard(Request $request){
        $filter = $request->filter;
        if($filter!= null){
            $blogs = Blog::select('blogs.*','users.id as user_id')
                            ->join('users','blogs.user_id','=','users.id')
                            ->where('user_id',$filter)
                            ->get();
        }else{
            $blogs = Blog::get();
        }
        $users = User::get();
        
        return view('dashboard',compact('blogs','users'));
    }

    public function create_blog(){
        return view('create_blog');
    }

    public function edit_blog($id){
        $blog = Blog::where('id',decrypt($id))->first();
        return view('edit',compact('blog'));
    }

    public function store(Request $request){ 
        $request->validate([
            'title'=>'required|min:5:max:100',
            'content'=>'required',
        ]);
       $user_id = Session::get('userlogin');
        $blog = new Blog;
        if($request->image!=''){
            $request->validate([
                'image' => 'mimes:png,jpg,jpeg|max:2048'
            ]);
            $fileName = time().'.'.$request->image->getClientOriginalExtension();
            $filePath = $request->image->move('uploads', $fileName);
        }else{
            $fileName = '';
        }
        $slug = Str::slug($request->title);
        $blog_exist = Blog::where('slug',$slug)->first();
        if($blog_exist != ''){
            return redirect()->back()->with('error', 'Blog already exist !!');
        }
        $blog->title = $request->title;
        $blog->content = $request->content;
        $blog->image = $fileName;
        $blog->slug = Str::slug($request->title);
        $blog->user_id = $user_id;
        if($blog->save()){
            return redirect('dashboard')->with('success', 'Blog submitted !!');
        }else{
            return redirect()->back()->with('error', 'Something wrong !!');
        }


    }

    public function update(Request $request){
        $request->validate([
            'title'=>'required|min:5:max:100',
            'content'=>'required',
        ]);
        $id = decrypt($request->blog_id);
        $slug = Str::slug($request->title);
        $user_id = Session::get('userlogin');
        $blog_exist = Blog::where('slug',$slug)->where('id','!=',$id)->first();
        if($blog_exist != ''){
            return redirect()->back()->with('error', 'Blog already exist !!');
        }
        $blog = Blog::find($id);
        if($request->image!=''){
            $request->validate([
                'image' => 'mimes:png,jpg,jpeg|max:2048'
            ]);
            $fileName = time().'.'.$request->image->getClientOriginalExtension();
            $filePath = $request->image->move('uploads', $fileName);
        }else{
            $fileName = $request->old_image;
        }
        $blog->title = $request->title;
        $blog->content = $request->content;
        $blog->image = $fileName;
        if($blog->save()){
            return redirect('dashboard')->with('success', 'Blog updated !!');
        }else{
            return redirect()->back()->with('error', 'Something wrong !!');
        }


    }

    public function blog_delete($id){
        $id = decrypt($id);
        $delete = Blog::where('id',$id)->delete();
        if($delete){
            return redirect('dashboard')->with('success', 'Blog deleted successfully !!');
        }else{
            return redirect()->back()->with('error', 'Something wrong !!');
        }
    }

    public function single_blog($slug){
        $single_blog = Blog::where('slug',$slug)->first();
        $comments = DB::table('comments')->where('blog_id',$single_blog->id)->get();
        return view('single_blog',compact('single_blog','comments'));
    }

    public function comment(Request $request){
        $comment = DB::table('comments')->insert(['blog_id'=>$request->blog_id,'name'=>$request->name,'email'=>$request->email,'comment'=>$request->comment]);
        if($comment){
            return redirect()->back()->with('success', 'Commented successfully !!');
        }else{
            return redirect()->back()->with('error', 'Something wrong !!');
        }
    }
}
